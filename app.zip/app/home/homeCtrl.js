app.controller("homeCtrl", ["$scope", "$routeParams", "customerService", function($scope, $routeParams, customerService) {


    customerService.getCustomerList().then(function(res) {
        console.log("getCustomerList", res.results);
        $scope.customers = res.results;
    });

    /*
        // callback method
        customerService.getCustomerList(function(res) {
            console.log("getCustomerList", res.results);
            $scope.customers = res.results;
        }); */

    $scope.addCustomer = function(data) {
        customerService.insertCustomer(data);
    }

    $scope.deleteCustomer = function(custID) {
        console.log("deleteCustomer", custID);
        customerService.deleteCustomer(custID);
    }
}]);

app.controller("editCtrl", ["$scope", "$routeParams", "customerService", "customer", function($scope, $routeParams, customerService, customer) {
    var custID = $routeParams.id || 0;
    var original = customer;
    console.log("custID", custID);
    // Using angular.copy() the two objects would remain seperate and changes would not reflect on each other.
    $scope.customer = angular.copy(original);
    $scope.customer._id = custID;
    console.log("customer", customer);
    //To compare two objects you can use:angular.equals(obj1, obj2) does not depend on the order of the keys
    $scope.isClean = function() {
        return angular.equals(original, $scope.customer);
    }
    $scope.saveCustomer = function(customer) {
        customerService.editCustomer(custID, customer);
    }


}]);