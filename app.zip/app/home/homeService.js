app.factory("customerService", ["$http", "$q", function($http, $q) {

    deferred = $q.defer();
    var CustomersList = [{
        customerNumber: 100,
        name: "bb",
        email: "bb@bb.com",
        city: "bb",
        country: "bb"
    }];
    var custObj = {};
    // ajax method 1
    /*
    custObj.getCustomerList = function() {
        return $http.get("https://randomuser.me/api/");
    } */

    // ajax method 2
    /*
    custObj.getCustomerList = function() {
        return $http.get("https://randomuser.me/api/").success(function(data) {
            return data;
        }).error(function(err) {
            return err;
        });
    } */

    // ajax method 3
    /*
    custObj.getCustomerList = function(callback) {
        $http.get("https://randomuser.me/api/").success(function(res) {
            callback(res);
        }).error(function(err) {
            callback(err);
        });
    } */

    // ajax method 4
    custObj.getCustomerList = function() {
        $http.get("https://randomuser.me/api/").success(function(res) {
            deferred.resolve(res);
        }).error(function(err) {
            deferred.reject(err);
        });
        return deferred.promise;
    }


    custObj.getCustomer = function(id) {

        for (key in CustomersList) {
            if (CustomersList[key].customerNumber == id) {
                console.log("CustomersList[key]", CustomersList[key]);
                return CustomersList[key];
            }
        }
    }
    custObj.editCustomer = function(id, data) {
        for (key in CustomersList) {
            if (CustomersList[key].customerNumber == id) {
                CustomersList[key] = data;
                console.log("editCustomer[key]", CustomersList);
            }
        }
    }
    custObj.deleteCustomer = function(id) {
        for (key in CustomersList) {
            if (CustomersList[key].customerNumber == id) {
                CustomersList.splice(key, 1);
                console.log("deleteCustomer[key]", CustomersList);
            }
        }
    }
    custObj.insertCustomer = function(data) {
        var custNo = Math.max.apply(Math, CustomersList.map(function(field) { return field.customerNumber; }));
        console.log("currentNo", custNo);
        if (custNo > 0) {
            data.customerNumber = parseInt(custNo) + 1;
        } else {
            data.customerNumber = 100;
        }

        CustomersList.push(data);
        console.log("CustomersList", CustomersList);

    }

    return custObj;

}]);