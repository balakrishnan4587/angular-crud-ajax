var app = angular.module("myApp", ["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
        .when("/", { templateUrl: "home/home.html", controller: "homeCtrl" })
        .when("/add-customer", { templateUrl: "home/addCustomer.html", controller: "homeCtrl" })
        .when("/edit-customer/:id", {
            templateUrl: "home/editCustomer.html",
            controller: "editCtrl",
            resolve: {
                customer: function(customerService, $route) {
                    var customerID = $route.current.params.id;
                    return customerService.getCustomer(customerID);
                }
            }
        })
        .otherwise({ redirectTo: "/" });

});